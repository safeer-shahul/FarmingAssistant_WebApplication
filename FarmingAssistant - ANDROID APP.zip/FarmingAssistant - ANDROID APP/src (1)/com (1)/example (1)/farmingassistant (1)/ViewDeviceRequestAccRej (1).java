package com.example.farmingassistant;

import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.GINGERBREAD) public class ViewDeviceRequestAccRej extends Activity {
ListView lv1;
Button b1,b2;
String did,oid,fid;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_device_request_acc_rej);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		lv1=(ListView)findViewById(R.id.listView1);
		b1=(Button)findViewById(R.id.button1);
		
		
		SoapObject obj=new SoapObject(soapclass.NAMESPACE,"acceprej"); 
		obj.addProperty("oid", Login.uid1);
		soapclass sc=new soapclass();
		String ou=sc.Callsoap(obj, "http://tempuri.org/acceprej");
		if(!ou.equals("error")&&!ou.equals(""))
		{
			String []s1=ou.split("@");
			ArrayList<HashMap<String,String>> arlst=new ArrayList<HashMap<String,String>>();
			for(int i=0;i<s1.length;i++)
			{
				
				HashMap<String,String> hmap=new HashMap<String, String>();
				String []s2=s1[i].split("#");
				hmap.put("a", s2[0]);
				hmap.put("b", s2[1]);
				hmap.put("c", s2[2]);
				
				
				arlst.add(hmap);
				
			}
			
			ListAdapter lis=new SimpleAdapter(ViewDeviceRequestAccRej.this, arlst, R.layout.devre, new String[]{"b","c"}, new int[]{R.id.textView3,R.id.textView4});
			lv1.setAdapter(lis);
		}
		else
		{
			Toast.makeText(getApplicationContext(), "No data", 3).show();
			}
		lv1.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				HashMap<String,String> hmap=(HashMap<String, String>)arg0.getItemAtPosition(arg2);
				did=hmap.get("c");
				
			}
		});
		
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				SoapObject obj=new SoapObject(soapclass.NAMESPACE,"acc"); 
				obj.addProperty("drid",did);
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/acc");
				if(!ou.equals("error")&&!ou.equals(""))
				{
				Toast.makeText(getApplicationContext(), "Accepted", 3)	.show();
				Intent i=new Intent(getApplicationContext(), OHome.class);
				i.addFlags(i.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
				}
				else
				{
					Toast.makeText(getApplicationContext(), "error", 3)	.show();
				}
			}
		});
		b2=(Button)findViewById(R.id.button2);
		b2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				SoapObject obj=new SoapObject(soapclass.NAMESPACE,"rej"); 
				obj.addProperty("drid",did);
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/rej");
				if(!ou.equals("error")&&!ou.equals(""))
				{
				Toast.makeText(getApplicationContext(), "Rejected", 3)	.show();
				Intent i=new Intent(getApplicationContext(), OHome.class);
				i.addFlags(i.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
				}
				else
				{
					Toast.makeText(getApplicationContext(), "error", 3)	.show();
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_device_request_acc_rej, menu);
		return true;
	}

}
