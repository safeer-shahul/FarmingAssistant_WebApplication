package com.example.farmingassistant;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.GINGERBREAD) public class ProductPayment extends Activity {
EditText ed1,ed2;
Button b1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_product_payment);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
final String pid=getIntent().getStringExtra("pid");
		
		final String prc=getIntent().getStringExtra("prc");
		ed1=(EditText)findViewById(R.id.editText1);
		ed2=(EditText)findViewById(R.id.editText2);
		b1=(Button)findViewById(R.id.button1);
		ed2.setText(prc);
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (!ed1.getText().toString().equals("") && (!ed2.getText().toString().equals("")))
				{
				SoapObject obj=new SoapObject(soapclass.NAMESPACE,"pay"); 
				obj.addProperty("uid", Login.uid1);
				obj.addProperty("prc", prc);
				obj.addProperty("pid",pid);
				obj.addProperty("acn", ed1.getText().toString());
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/pay");
				if(!ou.equals("error")&&!ou.equals(""))
				{
					Toast.makeText(getApplicationContext(), "Payed", 3).show();
					Intent i=new Intent(getApplicationContext(), Home.class);
					i.addFlags(i.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
				else
				{
					Toast.makeText(getApplicationContext(), "error", 3).show();
				}
				}
				else { 
					Toast.makeText(getApplicationContext(),"fill", 3).show();
				}
			}
				
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.product_payment, menu);
		return true;
	}

}
