package com.example.farmingassistant;

import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;

import com.example.farmingassistant.R.layout;
import com.example.farmingassistant.R.string;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.RatingBar;
import android.widget.SimpleAdapter;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.Spinner;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.GINGERBREAD) public class Rating extends Activity {
EditText ed1,ed3,ed5;
RatingBar r1;
Button b1;
String pid[],pnm[];
String prid,farid,rat;
Spinner sp1,sp2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rating);
		
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		ed1=(EditText)findViewById(R.id.editText1);
		
		ed3=(EditText)findViewById(R.id.editText3);
	
		
		r1=(RatingBar)findViewById(R.id.ratingBar1);
		b1=(Button)findViewById(R.id.button1);
		sp1=(Spinner)findViewById(R.id.spinner1);
		ed1=(EditText)findViewById(R.id.editText1);
		ed1.setFocusable(false);
		
		SoapObject obj=new SoapObject(soapclass.NAMESPACE,"productsview"); 
		soapclass sc=new soapclass();
		String ou=sc.Callsoap(obj, "http://tempuri.org/productsview");
		if(!ou.equals("error")&&!ou.equals(""))
		{
			String []s1=ou.split("@");
			pid=new String[s1.length];
			pnm=new String[s1.length];
			for(int i=0;i<s1.length;i++)
			{
				
				
				String []s2=s1[i].split("#");
				pid[i]=s2[0];
				pnm[i]=s2[1];
				ArrayAdapter<String> ad=new ArrayAdapter<String>(Rating.this, android.R.layout.simple_spinner_item,pnm);
				sp1.setAdapter(ad);
				
			}
			
			
		}
		else
		{
			
			}
		sp1.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				
				prid=pid[arg2];
				SoapObject obj=new SoapObject(soapclass.NAMESPACE,"prd_far"); 
				obj.addProperty("pid", prid);
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/prd_far");
				if(!ou.equals("error")&&!ou.equals(""))
				{
					String pr_fa[]=ou.split("#");
					ed1.setText(pr_fa[0]);
					farid=pr_fa[1];
					
				}
				else
				{
					
				}
				
				
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
			
		});
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				SoapObject obj=new SoapObject(soapclass.NAMESPACE,"rating"); 
				obj.addProperty("prodid",prid);
				obj.addProperty("farmid",farid);
				obj.addProperty("rating",rat);
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/rating");
				if(!ou.equals("error")&&!ou.equals(""))
				{
					Toast.makeText(getApplicationContext(),"Rating Added", 3).show();
					Intent i=new Intent(getApplicationContext(), Home.class);
					i.addFlags(i.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
				else
				{
					Toast.makeText(getApplicationContext(),"error", 3).show();	
				}
				
				
			}
			
		});
		r1.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
			
			@Override
			public void onRatingChanged(RatingBar arg0, float arg1, boolean arg2) {
				// TODO Auto-generated method stub
				rat=String.valueOf(r1.getRating());
				Toast.makeText(getApplicationContext(), rat, 3).show();
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.rating, menu);
		return true;
	}

}
