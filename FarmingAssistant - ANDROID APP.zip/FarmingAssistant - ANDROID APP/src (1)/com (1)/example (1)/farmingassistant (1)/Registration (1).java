package com.example.farmingassistant;

import java.util.Calendar;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.GINGERBREAD) public class Registration extends Activity {
EditText ed1,ed2,ed3,ed4,ed5;
Button b1,b2;
private int mYear, mMonth, mDay;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_registration);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		ed1=(EditText)findViewById(R.id.editText1);
		ed2=(EditText)findViewById(R.id.editText2);
		ed3=(EditText)findViewById(R.id.editText3);
		ed4=(EditText)findViewById(R.id.editText4);
		ed5=(EditText)findViewById(R.id.editText5);
		
		b1=(Button)findViewById(R.id.button1);
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				 final Calendar c = Calendar.getInstance();
		            mYear = c.get(Calendar.YEAR);
		            mMonth = c.get(Calendar.MONTH);
		            mDay = c.get(Calendar.DAY_OF_MONTH);


		            DatePickerDialog datePickerDialog = new DatePickerDialog(Registration.this,
		                    new DatePickerDialog.OnDateSetListener() {

		                        @Override
		                        public void onDateSet(DatePicker view, int year,
		                                              int monthOfYear, int dayOfMonth) {

		                            b1.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

		                        }
		                    }, mYear, mMonth, mDay);
		            datePickerDialog.show();
				
				
			
			}
		});
		b2=(Button)findViewById(R.id.button2);
		b2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(!ed3.getText().toString().matches("[a-zA-Z0-9._-]+@gmail+\\.+com+"))
				{
					
					ed3.setText("");
					
				}
				if(!(ed4.getText().toString().length()==10))
				{
					ed4.setText("");
				}
				if (!ed1.getText().toString().equals("") && (!ed2.getText().toString().equals("") && (!ed3.getText().toString().equals("") && (!ed4.getText().toString().equals("") && (!ed5.getText().toString().equals(""))))))
				{
				
				SoapObject obj=new SoapObject(soapclass.NAMESPACE,"usregistration"); 
				obj.addProperty("name",ed1.getText().toString());
				obj.addProperty("add",ed2.getText().toString());
				obj.addProperty("dob",b1.getText().toString());
				obj.addProperty("email",ed3.getText().toString());
				obj.addProperty("con",ed4.getText().toString());
				obj.addProperty("pass",ed5.getText().toString());
				
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/usregistration");
				if(!ou.equals("error")&&!ou.equals(""))
				{
				Toast.makeText(getApplicationContext(), "Registration Successfull", 3).show();
				Intent i=new Intent(getApplicationContext(), Login.class);
				i.addFlags(i.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i);
				}
				else
				{
					Toast.makeText(getApplicationContext(),"error", 3).show();	
				}
				}
				else { 
					Toast.makeText(getApplicationContext(),"fill", 3).show();
				}
			}
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.registration, menu);
		return true;
	}

}
