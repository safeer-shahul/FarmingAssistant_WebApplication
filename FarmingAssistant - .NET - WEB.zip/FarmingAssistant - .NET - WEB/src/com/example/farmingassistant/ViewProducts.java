package com.example.farmingassistant;

import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

@TargetApi(Build.VERSION_CODES.GINGERBREAD) public class ViewProducts extends Activity {
ListView lv1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_view_products);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		lv1=(ListView)findViewById(R.id.listView1);
		SoapObject obj=new SoapObject(soapclass.NAMESPACE,"productsview"); 
		
		soapclass sc=new soapclass();
		String ou=sc.Callsoap(obj, "http://tempuri.org/productsview");
		if(!ou.equals("error")&&!ou.equals(""))
		{
			String []s1=ou.split("@");
			ArrayList<HashMap<String,String>> arlst=new ArrayList<HashMap<String,String>>();
			for(int i=0;i<s1.length;i++)
			{
				
				HashMap<String,String> hmap=new HashMap<String, String>();
				String []s2=s1[i].split("#");
				hmap.put("a", s2[0]);
				hmap.put("b", s2[1]);
				hmap.put("c", s2[2]);
				hmap.put("d", s2[3]);
				hmap.put("e", s2[4]);
				arlst.add(hmap);
				
			}
			
			ListAdapter lis=new SimpleAdapter(ViewProducts.this, arlst, R.layout.farpro, new String[]{"b","c","d"}, new int[]{R.id.textView4,R.id.textView5,R.id.textView6});
			lv1.setAdapter(lis);
		}
		else
		{
			Toast.makeText(getApplicationContext(), "No data", 3).show();
			}
		
		lv1.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				HashMap<String,String> hmap=(HashMap<String, String>)arg0.getItemAtPosition(arg2);
			
				Intent i=new Intent(getApplicationContext(), RequestProduct.class);
				i.putExtra("pid",hmap.get("a"));
				i.putExtra("pnm",hmap.get("b"));
				i.putExtra("prc",hmap.get("d"));
				i.putExtra("fid",hmap.get("e"));
				startActivity(i);
			}
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_products, menu);
		return true;
	}

}
