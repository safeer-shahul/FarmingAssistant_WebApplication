package com.example.farmingassistant;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("NewApi") @TargetApi(Build.VERSION_CODES.GINGERBREAD) public class LandFarmer extends Activity {
EditText ed1,ed2,ed3,ed4;
Button b1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_land_farmer);
		
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		
		ed1=(EditText)findViewById(R.id.editText1);
		ed2=(EditText)findViewById(R.id.editText2);
		ed3=(EditText)findViewById(R.id.editText3);
		ed4=(EditText)findViewById(R.id.editText4);
		b1=(Button)findViewById(R.id.button1);
		ed1.setFocusable(false);
		ed2.setFocusable(false);
		ed3.setFocusable(false);
		SoapObject obj=new SoapObject(soapclass.NAMESPACE,"landusr"); 
		obj.addProperty("uid", Login.uid1);
		soapclass sc=new soapclass();
		String ou=sc.Callsoap(obj, "http://tempuri.org/landusr");
		if(!ou.equals("error")&&!ou.equals(""))
		{
			String land[]=ou.split("#");
			ed1.setText(land[0]);
			ed2.setText(land[1]);
			ed3.setText(land[2]);
			
		}
		else
		{
			
		}
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (!ed1.getText().toString().equals("") && (!ed2.getText().toString().equals("") && (!ed3.getText().toString().equals("") && (!ed4.getText().toString().equals("")))))
				{
				SoapObject obj=new SoapObject(soapclass.NAMESPACE,"farmland"); 
				obj.addProperty("uid",Login.uid1);
				obj.addProperty("add",ed1.getText().toString());
				obj.addProperty("con",ed2.getText().toString());
				obj.addProperty("email",ed3.getText().toString());
				obj.addProperty("det",ed4.getText().toString());
				obj.addProperty("type",Login.ty);
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/farmland");
				if(!ou.equals("error")&&!ou.equals(""))
				{
					Toast.makeText(getApplicationContext(),"Details Added", 3).show();
					Intent i=new Intent(getApplicationContext(), Home.class);
					i.addFlags(i.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
				}
				else
				{
					Toast.makeText(getApplicationContext(),"error", 3).show();	
				}
				}
				else { 
					Toast.makeText(getApplicationContext(),"fill", 3).show();
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.land_farmer, menu);
		return true;
	}

}
