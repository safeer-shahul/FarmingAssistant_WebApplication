package com.example.farmingassistant;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.GINGERBREAD)
public class PostQueryNViewResponse extends Activity {
	EditText ed4;
	Button b1;
	Spinner sp;
	String[] fid, fnm;
	String finalfnm;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_post_query_nview_response);
		try {
			if (android.os.Build.VERSION.SDK_INT > 9) {
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
						.permitAll().build();
				StrictMode.setThreadPolicy(policy);
			}
		} catch (Exception e) {

		}

		sp = (Spinner) findViewById(R.id.spinner1);
		ed4 = (EditText) findViewById(R.id.editText4);
		b1 = (Button) findViewById(R.id.button1);

		SoapObject obj = new SoapObject(soapclass.NAMESPACE, "farmview");
		soapclass sc = new soapclass();
		String ou = sc.Callsoap(obj, "http://tempuri.org/farmview");
		if (!ou.equals("error") && !ou.equals("")) {
			String[] k = ou.split("@");
			fid = new String[k.length];
			fnm = new String[k.length];
			for (int i = 0; i < k.length; i++) {
				String[] q = k[i].split("#");
				fid[i] = q[0];
				fnm[i] = q[1];

			}
			ArrayAdapter<String> ad = new ArrayAdapter<String>(
					PostQueryNViewResponse.this,
					android.R.layout.simple_spinner_item, fnm);
			sp.setAdapter(ad);
		}
		sp.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				finalfnm = sp.getSelectedItem().toString();
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub

			}
		});

		b1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (((!finalfnm.equals("select") && !ed4.getText().toString().equals("")))) {
					SoapObject obj = new SoapObject(soapclass.NAMESPACE,
							"postquery");

					obj.addProperty("farmername", finalfnm);
					obj.addProperty("query", ed4.getText().toString());
					soapclass sc = new soapclass();
					String ou = sc
							.Callsoap(obj, "http://tempuri.org/postquery");
					if (!ou.equals("error") && !ou.equals("")) {
						Toast.makeText(getApplicationContext(), "Query Posted",
								3).show();
						Intent i = new Intent(getApplicationContext(),
								Home.class);
						i.addFlags(i.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);

					} else {
						Toast.makeText(getApplicationContext(), "error", 3)
								.show();
					}
				} else {
					Toast.makeText(getApplicationContext(), "fill", 3).show();
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.post_query_nview_response, menu);
		return true;
	}

}
