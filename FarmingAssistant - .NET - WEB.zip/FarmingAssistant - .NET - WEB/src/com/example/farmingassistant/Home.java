package com.example.farmingassistant;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

@TargetApi(Build.VERSION_CODES.GINGERBREAD) public class Home extends Activity {
Button b1,b2,b3,b5,b6,b8;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.u_home);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		b2=(Button)findViewById(R.id.button2);
	    b2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
Intent i=new Intent(getApplicationContext(), RequestAvail.class);
				
				startActivity(i);
			
			}
		});
	    b3=(Button)findViewById(R.id.button3);
	    b3.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
Intent i=new Intent(getApplicationContext(), ViewProducts.class);
				
				startActivity(i);
			}				
			
		});
		
		b5=(Button)findViewById(R.id.button5);
		b5.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
Intent i=new Intent(getApplicationContext(), Rating.class);
				
				startActivity(i);
			}	
			
		});
		b6=(Button)findViewById(R.id.button6);
		b6.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
Intent i=new Intent(getApplicationContext(), LandFarmer.class);
				
				startActivity(i);
			}
		});
		b1=(Button)findViewById(R.id.button1);
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
Intent i=new Intent(getApplicationContext(), PostQueryNViewResponse.class);
				
				startActivity(i);
			}
		});


		b8=(Button)findViewById(R.id.button8);
		b8.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
Intent i=new Intent(getApplicationContext(), Login.class);
				
				startActivity(i);
			}
		});
			
	}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home, menu);
		return true;
	}

}
