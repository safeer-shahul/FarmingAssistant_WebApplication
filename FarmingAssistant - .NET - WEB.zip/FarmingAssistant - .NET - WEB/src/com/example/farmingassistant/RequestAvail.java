package com.example.farmingassistant;

import java.util.ArrayList;
import java.util.HashMap;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.GINGERBREAD) public class RequestAvail extends Activity {
Spinner sp1;
ListView lv1;
Button b1;
String pid;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_request_avail);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		sp1=(Spinner)findViewById(R.id.spinner1);
		lv1=(ListView)findViewById(R.id.listView1);
		b1=(Button)findViewById(R.id.button1);
		
		SoapObject obj=new SoapObject(soapclass.NAMESPACE,"dis"); 
		soapclass sc=new soapclass();
		String ou=sc.Callsoap(obj, "http://tempuri.org/dis");
		if(!ou.equals("error")&&!ou.equals(""))
		{
			String []pty=ou.split("@");
			ArrayAdapter<String> ad=new ArrayAdapter<String>(RequestAvail.this, android.R.layout.simple_spinner_item,pty);
			sp1.setAdapter(ad);
			
			
			
		}
		sp1.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				if(!sp1.getSelectedItem().toString().equals("-SELECT-"))
				{
				SoapObject obj=new SoapObject(soapclass.NAMESPACE,"prodet"); 
				obj.addProperty("pt", sp1.getSelectedItem().toString());
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/prodet");
				if(!ou.equals("error")&&!ou.equals(""))
				{
					String []s1=ou.split("@");
					ArrayList<HashMap<String,String>> arlst=new ArrayList<HashMap<String,String>>();
					for(int i=0;i<s1.length;i++)
					{
						
						HashMap<String,String> hmap=new HashMap<String, String>();
						String []s2=s1[i].split("#");
						hmap.put("a", s2[0]);
						hmap.put("b", s2[1]);
						hmap.put("c", s2[2]);
						arlst.add(hmap);
						
					}
					
					ListAdapter lis=new SimpleAdapter(RequestAvail.this, arlst, R.layout.availpro, new String[]{"b","c"}, new int[]{R.id.textView1,R.id.textView2});
					lv1.setAdapter(lis);
				}
				else
				{
					Toast.makeText(getApplicationContext(), "No data", 3).show();
					}
				}
				else
				{
					
					Toast.makeText(getApplicationContext(), "Select Product Type", 3).show();
				}

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		lv1.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				HashMap<String,String> hmap=(HashMap<String, String>)arg0.getItemAtPosition(arg2);
				pid=hmap.get("a");
			}
		});
		
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				SoapObject obj=new SoapObject(soapclass.NAMESPACE,"reqavail"); 
				obj.addProperty("prodid", pid);
				obj.addProperty("uid", Login.uid1);
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/reqavail");	
				if(!ou.equals("error")&&!ou.equals(""))
				{
					Toast.makeText(getApplicationContext(), "Requested", 3).show();
				}
				else
				{
					Toast.makeText(getApplicationContext(), "error", 3).show();	
				}
			}
		});
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.request_avail, menu);
		return true;
	}

}
