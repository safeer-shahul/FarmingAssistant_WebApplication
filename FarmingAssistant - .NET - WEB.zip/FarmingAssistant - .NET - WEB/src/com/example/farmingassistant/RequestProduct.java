package com.example.farmingassistant;

import org.ksoap2.serialization.SoapObject;

import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.GINGERBREAD) public class RequestProduct extends Activity {
TextView t1,t2;
Button b1,b2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_request_product);
		try
    	{
    		if (android.os.Build.VERSION.SDK_INT > 9) 
    		{
    			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    			StrictMode.setThreadPolicy(policy);
    		}
    	}
    	catch(Exception e)
    	{
    		
    	}
		
		final String pid=getIntent().getStringExtra("pid");
		final String pnm=getIntent().getStringExtra("pnm");
		final String prc=getIntent().getStringExtra("prc");
		final String fid=getIntent().getStringExtra("fid");
		t1=(TextView)findViewById(R.id.textView4);
		t2=(TextView)findViewById(R.id.textView5);
		b1=(Button)findViewById(R.id.button1);
		b2=(Button)findViewById(R.id.button2);
		t1.setText(pnm);
		t2.setText(prc);
		Toast.makeText(getApplicationContext(), pnm, 3).show();
		Toast.makeText(getApplicationContext(), prc, 3).show();
		b2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i=new Intent(getApplicationContext(), PaymentStatus.class);
				i.putExtra("prc", t2.getText().toString());
				i.putExtra("pid", pid);
				startActivity(i);
			}
		});
		
		
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				SoapObject obj=new SoapObject(soapclass.NAMESPACE,"reqprod"); 
				obj.addProperty("prodid", pid);
				obj.addProperty("userid", Login.uid1);
				obj.addProperty("farmerid", fid);
				soapclass sc=new soapclass();
				String ou=sc.Callsoap(obj, "http://tempuri.org/reqprod");	
				if(!ou.equals("error")&&!ou.equals(""))
				{
					Toast.makeText(getApplicationContext(), "Requested", 3).show();
					Intent i=new Intent(getApplicationContext(), ViewProducts.class);
					
					startActivity(i);
				}
				else
				{
					Toast.makeText(getApplicationContext(), "error", 3).show();	
				}
			}
		});
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.request_product, menu);
		return true;
	}

}
